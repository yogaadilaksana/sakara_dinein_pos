-- DropIndex
DROP INDEX `Shift_user_id_key` ON `Shift`;
