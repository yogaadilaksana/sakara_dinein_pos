-- DropForeignKey
ALTER TABLE `Shift` DROP FOREIGN KEY `Shift_user_id_fkey`;
