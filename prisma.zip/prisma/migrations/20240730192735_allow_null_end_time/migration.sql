-- AlterTable
ALTER TABLE `Shift` MODIFY `end_time` DATETIME(3) NULL;
