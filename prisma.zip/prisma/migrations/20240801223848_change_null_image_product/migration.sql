-- AlterTable
ALTER TABLE `Product` MODIFY `image` VARCHAR(191) NULL;
